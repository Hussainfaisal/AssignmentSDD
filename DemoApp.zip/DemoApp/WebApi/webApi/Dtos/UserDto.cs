﻿using System.ComponentModel.DataAnnotations;

namespace webApi.Dtos
{
    public class UserDto
    {
        //[Key]
        //[Required]
        public int Id { get; set; }
        public string loginName { get; set; }
        public string password { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

    }
}
