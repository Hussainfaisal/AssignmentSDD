﻿using System.ComponentModel.DataAnnotations;

namespace webApi.Dtos
{
    public class LoginDto
    {
        
        
        public string? name { get; set; }
        public string? Password { get; set; }
       


    }
    public class LoginRespDto
    {
        public string? LoginName { get; set; }
        public string? responseMessage { get; set; }
        public string? isAdmin { get; set; }


    }
    
}
