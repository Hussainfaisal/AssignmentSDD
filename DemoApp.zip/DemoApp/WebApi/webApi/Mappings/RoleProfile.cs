using AutoMapper;
using webApi.Dtos;
using webApi.Models;

namespace webApi.Mappings
{
    public class RoleProfile : Profile
    {
        public RoleProfile()
        {
            //Source -> Target
            //CreateMap<Role, RoleReadDto>();
            //CreateMap<RoleCreateDto, Role>();

        }

    }
    
}