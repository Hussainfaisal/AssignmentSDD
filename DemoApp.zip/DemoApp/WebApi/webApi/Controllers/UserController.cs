﻿using Microsoft.AspNetCore.Mvc;
using webApi.Repositories;
using webApi.Models;
using webApi.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
//using AutoMapper;

namespace webApi.Controllers
{
  

    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _empRepo;

        public UserController(IUserRepository empRepo)//,IMapper mapper)
        {
            _empRepo = empRepo;
            // _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var Users = await _empRepo.GetUsers();

                return Ok(Users);
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }


        [HttpGet("{id}", Name = "EmployeById")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var User = await _empRepo.GetUser(id);
                if (User == null)
                    return NotFound();
                //return Ok(_mapper.Map<IEnumerable<DepartmentReadDto>>(departments));

                return Ok(User);
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }

       
        //[Authorize]
        [HttpPost]
        public async Task<IActionResult> AddUser([FromBody] User model)
        {
            try
            {
                var resp = await _empRepo.AddUser(model);
                
                return Ok(resp);
               

            }
            catch (Exception ex)
            {

                return StatusCode(500, ex.Message);
            }

        }

        [Route("UpdateUser")]
        [HttpPost]//("UpdateUser/{id}")]
        public async Task<IActionResult> UpdateUser([FromBody] User model)
        {
            try
            {
                var empId = await _empRepo.UpdateUser(model);
                return Ok(empId);
                //if (empId > 0)
                //{
                //    return Ok(empId);
                //}
                //else
                //{
                //    return NotFound();
                //}

            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int? id)
        {
            try
            {
                var empId = await _empRepo.DeleteUser(id);
                return Ok(empId);
                //if (empId > 0)
                //{
                //    return Ok(empId);
                //}
                //else
                //{
                //    return NotFound();
                //}
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }

        [AllowAnonymous]
        [Route("Login")]
        [HttpPost]//("UpdateUser/{id}")]
        public async Task<IActionResult> Login([FromBody] LoginDto model)
        {
            try
            {
                    var resp = await _empRepo.Login(model);
                    if (resp == null)
                        return NotFound();
                    return Ok(resp);
                

            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }

        }

        //[Authorize(Roles = "Admin")]
        //[AllowAnonymous]
        //[Route("Register")]
        //public async Task<IHttpActionResult> Register(UserModel userModel)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }


        //    IdentityResult result = await _repo.RegisterUser(userModel);

        //    IHttpActionResult errorResult = GetErrorResult(result);

        //    if (errorResult != null)
        //    {
        //        return errorResult;
        //    }

        //    return Ok();
        //}


    }
}
