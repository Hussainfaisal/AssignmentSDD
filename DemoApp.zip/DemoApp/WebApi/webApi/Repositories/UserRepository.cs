﻿using webApi.DBContext;
using webApi.Models;
using Dapper;
using System.Data;
using webApi.Dtos;

namespace webApi.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly DapperContext _context;
        public UserRepository(DapperContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<User>> GetUsers()
        {

            var query = "SELECT * FROM Users";
            using (var connection = _context.CreateConnection())
            {
                var Users = await connection.QueryAsync<User>(query);
                return Users.ToList();
            }
        }
        public async Task<User> GetUser(int? id)
        {
            var query = "SELECT * FROM Users WHERE Id = @Id";
            using (var connection = _context.CreateConnection())
            {
                var User = await connection.QuerySingleOrDefaultAsync<User>(query, new { id });
                return User;
            }
        }

        //public async Task<IEnumerable<UserDto>> GetUsersByRoleId(int id)
        //{
        //    var procedureName = "usp_GetEmpByRoletId";
        //    var parameters = new DynamicParameters();
        //    parameters.Add("Id", id, DbType.Int32, ParameterDirection.Input);
        //    using (var connection = _context.CreateConnection())
        //    {
        //        var User = await connection.QueryAsync<UserDto>
        //            (procedureName, parameters, commandType: CommandType.StoredProcedure);
        //        return User.ToList();
        //    }

        //}


        public async Task<IEnumerable<string>> AddUser(User emp)
        {
            var procedureName = "uspAddUser";
            var parameters = new DynamicParameters();
            parameters.Add("pLogin", emp.loginName, DbType.String);
            parameters.Add("pPassword", emp.password, DbType.String);
            parameters.Add("pFirstName", emp.firstName, DbType.String);
            parameters.Add("pLastName", emp.lastName, DbType.String);
            //parameters.Add("retVal", DbType.String, direction: ParameterDirection.Output);

            using var connection = _context.CreateConnection();
            var result = await connection.QueryAsync<string>
                (procedureName, parameters, commandType: CommandType.StoredProcedure);
            return result;
        }
        public async Task<IEnumerable<string>> UpdateUser(User emp)
        {
            //int result = 0;

            var procedureName = "uspUpdateUser";
            var parameters = new DynamicParameters();
            parameters.Add("pUserID", emp.Id, DbType.Int32);
            parameters.Add("pFirstName", emp.firstName, DbType.String);
            parameters.Add("pLastName", emp.lastName, DbType.String);
            //parameters.Add("retVal", DbType.String, direction: ParameterDirection.Output);
            using var connection = _context.CreateConnection();
            var result = await connection.QueryAsync<string>
                (procedureName, parameters, commandType: CommandType.StoredProcedure);
            return result;
        }

        public async Task<IEnumerable<string>> DeleteUser(int? id)
        {
            var procedureName = "uspDeleteUser";
            var parameters = new DynamicParameters();
            parameters.Add("pUserID", id, DbType.Int32, ParameterDirection.Input);

            using (var connection = _context.CreateConnection())
            {
                var result = await connection.QueryAsync<string>
                    (procedureName, parameters, commandType: CommandType.StoredProcedure);
                return result;
            }

        }

        //public async Task<User> Login(LoginDto login)
        //{
        //    int id = 1;
        //    var query = "SELECT * FROM Users WHERE Id = 3";
        //    using (var connection = _context.CreateConnection())
        //    {
        //        var User = await connection.QuerySingleOrDefaultAsync<User>(query, new { id });
        //        return User; 
        //    }
        //}

        public async Task<LoginRespDto> Login(LoginDto login)
        {
            var procedureName = "uspLogin";
            var parameters = new DynamicParameters();
            parameters.Add("pLoginName", login.name, DbType.String);
            parameters.Add("pPassword", login.Password, DbType.String);
            //parameters.Add("responseMessage", DbType.String, direction: ParameterDirection.Output);

            using var connection = _context.CreateConnection();
            var result = await connection.QuerySingleOrDefaultAsync<LoginRespDto>
                (procedureName, parameters, commandType: CommandType.StoredProcedure);
            
            return result;
        }



    }
}
