﻿using Dapper;
using webApi.DBContext;
using System.Data;

namespace webApi.Repositories
{
    public class DapperRepository : IDapperRepository
    {
        private readonly DapperContext _context;
        public DapperRepository(DapperContext context)
        {
            _context = context;
        }
        public List<T> GetAll<T>(string query, DynamicParameters sp_params, CommandType commandType = CommandType.StoredProcedure)
        {
            using (var db = _context.CreateConnection())
            {
                return db.Query<T>(query, sp_params, commandType: commandType).ToList();
            }


        }


public T execute_sp<T>(string query, DynamicParameters sp_params, CommandType commandType = CommandType.StoredProcedure)
        {
            T result;
            using (var dbConnection = _context.CreateConnection())
            {
                if (dbConnection.State == ConnectionState.Closed)
                    dbConnection.Open();
                using var transaction = dbConnection.BeginTransaction();
                try
                {
                    dbConnection.Query<T>(query, sp_params, commandType: commandType, transaction: transaction);
                    result = sp_params.Get<T>("retVal"); //get output parameter value
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            };
            return result;
        }
    }
}