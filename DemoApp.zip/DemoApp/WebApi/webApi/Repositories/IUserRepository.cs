﻿using webApi.Dtos;
using webApi.Models;

namespace webApi.Repositories
{
    public interface IUserRepository
    {
             
        Task<IEnumerable<User>> GetUsers();
        Task<User> GetUser(int? Id);

        Task<IEnumerable<string>> AddUser(User User);

        Task<IEnumerable<string>> DeleteUser(int? Id);

        Task<IEnumerable<string>> UpdateUser(User User);
        //Task<IEnumerable<UserDto>> GetUsersByRoleId(int id);

        Task<LoginRespDto> Login(LoginDto login);

        

    }
}
