export interface CurrentUser {
    id: string;
    userAccount?: string;
    firstName?: string;
    lastName?: string;
    jobTitle?: string;
    enabled?: boolean;
}

export interface APIResponse {
    status: boolean;
    data: any;
    errorMessage: any;
}

export interface UserInfo {
    name: string;
    givenName:string;
    surname:string;
}