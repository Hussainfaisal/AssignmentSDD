import { Component,inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../Services/auth/auth.service';
// import { ActivatedRoute } from '@angular/router';
import { NgIf, NgFor } from '@angular/common';  
import { ToastrService } from 'ngx-toastr';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    NgIf, NgFor,
    ReactiveFormsModule,RouterModule,   
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  authService = inject(AuthService);
  router = inject(Router);
  toastr= inject(ToastrService)
  // route: ActivatedRoute = inject(ActivatedRoute);

  protected loginForm = new FormGroup({
    name: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required])
  })

  onSubmit(){
    if(this.loginForm.valid){
      //console.log("On Submit : "+this.loginForm.value);
      this.authService.login(this.loginForm.value)
      .subscribe((data: any) => {
        if(this.authService.isLoggedIn())
          {
          this.router.navigate(['/dashboard']);
         }
         else
         {
        
          //console.log(data.responseMessage);
          this.toastr.error(data.responseMessage, 'Login Failed', {});
         }
        //console.log(data);
      }
    
    );
    }
    else
    {
      this.toastr.error('Please provide all required value', 'Required Field', {});
    
    }
   
    
   




  }


  






}
