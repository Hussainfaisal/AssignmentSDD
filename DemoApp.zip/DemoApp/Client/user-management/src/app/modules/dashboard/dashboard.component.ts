import { Component,inject } from '@angular/core';
import { AuthService } from '../../Services/auth/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


import { HttpBackend,HttpClient } from '@angular/common/http';

import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

 
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
  
    

  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

  authService = inject(AuthService);
  router = inject(Router);
  toastr= inject(ToastrService);
  tranSer=inject(TranslateService);
  //http=inject(HttpClient);
  
  
 
  public changeLangage(lang: string) {
   //const url:string ='./assets/i18n/en.json';
   /* this.http.get(url).subscribe((resp)=>
  {console.log(resp);});
     */
    this.tranSer.setDefaultLang(lang);
   this.tranSer.use(lang);
   console.log(this.tranSer.defaultLang);
  } 

  public logout(){
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  public addNewUser(){
    this.router.navigate(['/addNewUser']);
  }

 
}
