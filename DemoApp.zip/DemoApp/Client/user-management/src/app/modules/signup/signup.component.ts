import { Component,inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../Services/auth/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  authService  =  inject(AuthService);
  router  =  inject(Router);
  toastr= inject(ToastrService)
  public signupForm = new FormGroup({
    loginName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required])
  })

  public onSubmit() {
    if (this.signupForm.valid) {
      console.log(this.signupForm.value);
      this.authService.signup(this.signupForm.value)
        .subscribe({
          next: (data: any) => {
            console.log(data);
            
            var rep= data[0];       
            if(rep==='Success')
              {
              this.router.navigate(['/login']);
             }
             else
             {
            
              //console.log(data.responseMessage);
              this.toastr.error(rep, 'Sigup failed', {});
             }
          },
          error: (err) =>  this.toastr.error(err, 'Sigup failed', {})// console.log(err)
        });
    }
    else
    {
      this.toastr.error('Please provide all required value', 'Required Field', {});
    
    }
  }


}
