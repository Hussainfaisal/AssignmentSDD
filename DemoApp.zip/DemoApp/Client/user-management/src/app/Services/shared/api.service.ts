import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, EMPTY, Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { NotificationService } from '../notification/notification.service';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  //apiBaseUrl = environment.ApiBaseUrl + environment.ApiVersion + "/";
  apiBaseUrl = "";
  headers: HttpHeaders;
  constructor(private http: HttpClient, private notifyService: NotificationService)
   {
    this.headers = this.setHeaders();
   }

   public bindOrigin(req: string) {
    return environment.ApiBaseUrl + environment.ApiVersion + "/" + req;
  }

  get(url: string, options?: HttpParams): Observable<any> {
    this.ensureLoggedIn();
    url = this.bindOrigin(url);
    return this.http.get(url, { headers: this.headers, params: options }).pipe(
      catchError((err) => {
        console.log(err);
        this.notifyService.showError("Server Error, Failed!! " + err.message, " Template")
        return this.handleError(err);
      })
    );
  }

  getBlob(url: string): Observable<Blob> {
    this.ensureLoggedIn();
    url = this.bindOrigin(url);
    return this.http.get(url, { responseType: 'blob' });
  }

  post(url: string, body: any, options?: HttpParams): Observable<any> {
    this.ensureLoggedIn();
    url = this.bindOrigin(url);
    return this.http
      .post(url, body, { headers: this.headers, params: options })
      .pipe(
        catchError((err) => {
          this.notifyService.showError("Server Error, Failed!! \r\n" + err.message, " Template")
          return this.handleError(err);
        })
      );
  }

  put(url: string, body: any, options?: HttpParams): Observable<any> {
    this.ensureLoggedIn();
    url = this.bindOrigin(url);
    return this.http
      .put(url, body, { headers: this.headers, params: options })
      .pipe(
        catchError((err) => {
          console.log(err);
          this.notifyService.showError("Server Error, Failed!! " + err.message, " Template")
          return this.handleError(err);
        })
      );
  }

  delete(url: string, options?: HttpParams): Observable<any> {
    this.ensureLoggedIn();
    url = this.bindOrigin(url);
    return this.http
      .delete(url, { headers: this.headers, params: options })
      .pipe(
        catchError((err) => {
          console.log(err);
          this.notifyService.showError("Server Error, Failed!! " + err.message, " Template")
          return this.handleError(err);
        })

      );
  }

  public ensureLoggedIn() {
    let spaUrlValue = encodeURIComponent(window.location.href);
    let url = this.bindOrigin(`Account/SPALogin?spaUrl=${spaUrlValue}`);
    let url1 = this.bindOrigin(`Account/SPALogin?spaUrl=${encodeURIComponent(window.location.href)}`);

    var x = this.http.get<any>(url, {
      withCredentials: true,
    });

    x.pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status == 302) {

          window.location.href = url1;
          return EMPTY;
        } else {
          return throwError(() => error);
        }
      })
    ).subscribe();
  }


  private handleError(error: HttpErrorResponse) {
    console.log(error);

    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      if (error.error) {
        console.error(
          `Backend returned code ${error.status}, ` +
          `body was: ${JSON.stringify(error.error)}`
        );
      } else {
        console.error(
          `Backend returned code ${error.status}, ` + `body was: ${error}`
        );
      }
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  }


  // header setting
  private setHeaders() {
    let headers = new HttpHeaders();
    // when setting headers through 405 error need to check on server
    // headers = headers.set('Content-Type', 'application/json; charset=utf-8');
    // headers = headers.set('withCredentials', 'true');
    return headers;
  }

}

