import { Injectable,inject } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { CurrentUser, UserInfo } from '../../models/data.model'
//import { ApiService } from '../shared/api.service';
import { tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
 })
 export class AuthService {
   currentUser!: CurrentUser;
   private baseUrl="https://localhost:7028/api"
   constructor(private httpClient: HttpClient){  }


   signup(data: any) {
    console.log(data);
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
     return this.httpClient.post(`${this.baseUrl}/User`, data,httpOptions);
   }
      login(data: any) {
        //console.log("inside login"+data);
          return this.httpClient.post(`${this.baseUrl}/User/Login`, data)
          .pipe(tap((result) => {
            
            const resp = JSON.stringify(result);
            const obj = JSON.parse(resp);
            //console.log(obj.responseMessage);
            if(obj.responseMessage==='User successfully logged in')
              {
                localStorage.setItem('authUser', JSON.stringify(result));
              }
          }));
      }
      logout() {
        localStorage.removeItem('authUser');
      }
      isLoggedIn() {
        return localStorage.getItem('authUser') !== null;
      } 

      update(data: any) {
        console.log(data);
        const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
         return this.httpClient.post(`${this.baseUrl}/User/UpdateUser`, data,httpOptions);
       }

       delete(data: any) {
        console.log(data);
        
         return this.httpClient.delete(`${this.baseUrl}/User`, data);
       }
   
        
   


}


