import { CanActivateFn } from '@angular/router';
// import { ActivatedRouteSnapshot,CanActivateFn,Router,RouterStateSnapshot,} from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  
  return inject(AuthService).isLoggedIn()
  ? true
  : inject(Router).navigate(['/login']) ;
  
/*   const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLoggedIn()) {
    return true;
  }
  router.navigate(['/login']);
  return false;
 */

};

/* export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
) => {
    return inject(TokenService).authenticated()
    ? true
    : inject(Router).createUrlTree(['/auth/login']);
};
}; */
