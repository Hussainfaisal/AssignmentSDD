import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor() { }

  showSuccess(message: string | undefined, title: string | undefined) {
   // this.toastr.success(message, title)
  }

  showError(message: string | undefined, title: string | undefined) {
    //this.toastr.error(message, title)
  }

  showInfo(message: string | undefined, title: string | undefined) {
    //this.toastr.info(message, title)
  }

  showWarning(message: string | undefined, title: string | undefined) {
    //this.toastr.warning(message, title)
  }
}
