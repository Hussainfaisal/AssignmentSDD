import { Routes } from '@angular/router';
import { LoginComponent } from './modules/login/login.component';
import { SignupComponent } from './modules/signup/signup.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { UserManagementComponent } from './modules/user-management/user-management.component';

import { authGuard } from './Services/auth/auth.guard';

export const routes: Routes = [
    {
        path: '', redirectTo: '/login', pathMatch: 'full'
    },
    {
        path: 'login', component: LoginComponent
    },
    {
        path: 'signup', component: SignupComponent
    },

    {
        path: 'dashboard', component: DashboardComponent, canActivate: [authGuard]
    },
    {
      path: 'addNewUser', component: UserManagementComponent, canActivate: [authGuard]
    },
    /* {
        path: 'userdetails/:id',
        component: DetailsComponent,
        title: 'Home details'
    } */
  
];
