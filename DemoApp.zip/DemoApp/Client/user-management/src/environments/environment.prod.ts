export const environment = {
  production: false,
  ApiBaseUrl: '#{ApiBaseUrlWeb}#',
   ApiVersion: '#{ApiVersionWeb}#'
};