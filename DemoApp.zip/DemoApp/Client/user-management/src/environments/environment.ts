export const environment = {
  production: false,
  ApiBaseUrl: "https://localhost:8099/api/",
  ApiVersion: "v1"  
};